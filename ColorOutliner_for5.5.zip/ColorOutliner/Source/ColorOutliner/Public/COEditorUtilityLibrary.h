// Copyright lurongjiu 2024 All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "COEditorUtilityLibrary.generated.h"

/**
 * 
 */
UCLASS()
class COLOROUTLINER_API UCOEditorUtilityLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
	//Blueprint utility

	/**
	 * @param Actor If the actor is invalid, return (-1, -1, -1, -1).
	 */
	UFUNCTION(BlueprintPure, BlueprintCallable, Category = "ColorOutlinerUtility", meta=(DevelopmentOnly))
	static FLinearColor GetActorItemColor(const AActor* Actor);

	/**
	 * @param Refresh Should the outline be refreshed immediately? If not, the item colors will be refreshed the next time they appear. During loop operations, you can uncheck this option and call "RefreshSceneOutliners" once after the loop ends to save overhead.
	 */
	UFUNCTION(BlueprintCallable, Category = "ColorOutlinerUtility", meta=(DevelopmentOnly))
	static void SetActorItemColor(const AActor* Actor,const FLinearColor Color = FLinearColor::White,const bool Refresh = true);

	/**
	 * @param Refresh Should the outline be refreshed immediately? If not, the item colors will be refreshed the next time they appear. During loop operations, you can uncheck this option and call "RefreshSceneOutliners" once after the loop ends to save overhead.
	 */
	UFUNCTION(BlueprintCallable, Category = "ColorOutlinerUtility", meta=(DevelopmentOnly))
	static void ClearActorItemColor(const AActor* Actor,const bool Refresh = true);

	
	/**
	 * Refresh the outlines to display the latest item colors.
	 */
	UFUNCTION(BlueprintCallable, Category = "ColorOutlinerUtility", meta=(DevelopmentOnly))
	static void RefreshSceneOutliners();

	
};
